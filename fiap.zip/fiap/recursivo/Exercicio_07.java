package br.com.fiap.recursivo;

public class Exercicio_07 {

	public static void main(String[] args) {
		
		/*
		 * 7) Escreva um m�todo em JAVA que receba por
			  par�metro dois n�meros inteiros (x e y). Retornar
              para o main() o resultado da pot�ncia de xy.
		 */

	}

	
	
	
	
}
