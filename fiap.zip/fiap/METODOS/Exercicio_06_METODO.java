package br.com.fiap.METODOS;

public class Exercicio_06_METODO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
