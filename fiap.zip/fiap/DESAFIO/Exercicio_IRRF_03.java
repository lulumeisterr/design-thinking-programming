package br.com.fiap.DESAFIO;

import java.util.Scanner;

public class Exercicio_IRRF_03 {

	public static void main(String[] args) {
	
		Scanner entrada = new Scanner(System.in);
		
		double vlsalario , IRFF;
		
		System.out.println("Solicite o valor do salario");
		vlsalario = entrada.nextDouble();
		

	}

}
