package br.com.fiap.FOR_WHILE;

public class Exercicio06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//	int n1 = 10;
		
	for (int n1 = 10; n1 <=50; n1+=2) {
		System.out.println(n1);
		//n1 = n1 * 1 + 10;
		
		
	}
	for (int n1 = 10; n1 <=50; n1++) {
		if(n1%2==0)
		    System.out.println(n1);
		//n1 = n1 * 1 + 10;
		
		
	}
	

	//System.out.println("======================");
	
	//int n2 = 50;
	
	//for (int i = 0; i <6; i++) {
	//	System.out.println(n2);
	//	n2 = n2 * 1 + 10;
		
		
	//}
	
	}

}
