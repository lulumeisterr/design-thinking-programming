package br.com.fiap.FOR_WHILE;

public class Exercicio07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 10; i >= 10; i*=2) {
			System.out.println(i);
			
		}

	}
}