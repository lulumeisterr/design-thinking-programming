package br.com.fiap.FOR_WHILE;

public class Exercicio03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n1 = 50;
		
		/**
		 * Fa�a um programa que mostre 
		 * na tela todos os n�meros inteiros de
			50 a 0. 
		 */
//		
//		while(n1 > 0){
//			System.out.println(n1);
//			n1 --; //Decremento
//		}
		
		
		for (int i = 50; i >= 0; i--) {
			System.out.println(i);
		}
		
	}

}
