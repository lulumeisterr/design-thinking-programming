package br.com.fiap.FOR_WHILE;

public class Exercicio04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n1 = 49;
		
		while(n1 < 150){
			 n1 ++;
			System.out.println(n1);
			
		}
		
	}

}


