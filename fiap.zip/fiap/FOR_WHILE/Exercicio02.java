package br.com.fiap.FOR_WHILE;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/**
		 *   Fa�a um programa que mostre na tela
		 *    todos os n�meros inteiros de 0 a 50
		 */
		
		
		Scanner entrada = new Scanner(System.in);
		
		int n1 =0;
		
//		
//		while(n1 < 50){
//			n1 = n1 +1;
//			System.out.println(n1);
//		}
		
		//==========================================================
		
		for (int i = 0; i < 51; i++) {
			System.out.println(i);
			
		}
		
	}

}
