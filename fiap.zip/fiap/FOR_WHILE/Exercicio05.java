package br.com.fiap.FOR_WHILE;

public class Exercicio05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		for (int i = 1; i <= 50; i+=1) {
			System.out.println(i);

		}

		//=============================================================
					//Formas de fazer 02

		//				int n1 = 49;
		//
		//				while(n1 <= 200){
		//					n1 ++;
		//
		//					if( n1 % 5 == 0){
		//						System.out.println(n1);
		//
		//					}

		//======================================================
						//Formas de fazer 03
		//	
		//		for(int i=50; i<=200; i++){
		//		if(i%5==0)
		//		 System.out.println(i);
		//		}



	}
}



